# Package provenance

Derived from the user-supplied, MIT-licensed open-workbench-kit_v1.1.0.zip.
Original archive SHA-256: `1cf232f98b221e7fe11bcafb25edb6557e83437a9adbba8d638fd5c207e2b6ab`.
The original LICENSE is retained unchanged. The original download was not modified.
Version 1.2.0 adds review fixes, beginner documentation, local educational calculators,
and optional MCP configuration examples. Only software, generic documentation,
templates and synthetic examples are distributed.

Private guides, screenshots, personal documents, assessment files, task answers,
credentials and live work outputs are excluded. This is an independent generic
preparation toolkit, not an organizer-approved submission or a complete simulator.
