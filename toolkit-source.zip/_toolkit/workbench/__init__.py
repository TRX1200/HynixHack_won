"""Offline, explicit-input helpers. No model, credentials, browser, or network use."""
__version__ = '1.2.0'
