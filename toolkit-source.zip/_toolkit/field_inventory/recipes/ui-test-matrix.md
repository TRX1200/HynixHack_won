# End-to-end use case coverage (`ui-test-matrix`)

**Implementation status: RECIPE_ONLY.** This card is a design/verification recipe, not bundled algorithm or application code. The inventory CLI retrieves advice; it does not implement this baseline or install its candidate libraries.

**Task families:** quality_security, web_app  
**Index family:** `quality`  
**Useful signals:** integration test, acceptance, workflow, user journey

## Suggested baseline to implement (not bundled)
Happy path + empty invalid boundary cases

## Conditional upgrade to consider after a working baseline
E2E automation if permitted

## Libraries / fallback
Primary candidates: unittest, pytest. Confirm the actual runtime, library availability, license and host permissions before use. Library names do not authorize installation, network calls or GUI actions.  
Fallback: unittest stdlib.

## Required verification
Manual browser and API result agree

## Main failure mode
Code unit tests do not prove UI interaction

## Implementation contract to hand to Codex
1. Read task requirements, source files, schema, output contract and permissions. Determine whether this recipe truly applies; enumerate counterexamples.
2. Implement the smallest working baseline with deterministic fixtures. Avoid unrelated stack changes.
3. Build an independent test oracle or invariant checker. Inject at least one deliberate violation to ensure it fails.
4. Verify the output, run cost/time measurements where relevant, and record **PASS / FAIL / NOT RUN** with command/evidence.
5. Promote upgrades only when baseline works and there is measured need. Never claim all edge cases or optimality without proof.

## Safety boundary
Generic, public code and synthetic fixtures only. Exam problems, raw data, work logs and private notes must not enter public Git. Do not install external AI models or transmit task data.

## Optional UI design route
When an actual screen is required, start at [UI guidance](../../docs/ui/README.md).
Run `python tools/ui_router.py <local-ui-profile.json> --json` from the kit root, then read
only the selected guidance. Keep the existing stack and record functional and visual checks separately.
This reference does not create a screen or prove visual quality.
