# Open Workbench Kit

**범용 로컬 작업 도구 + 재사용 가능한 Codex Skill + 근거·검증·보고서 양식.**
완성된 과제 답안, AI 모델, 원격 에이전트 서비스가 아닙니다. 공식 시험/채용 플랫폼과 무관한 독립 준비 도구입니다.

**처음이면 [첫 15분 따라 하기](docs/FIRST_15_MINUTES_KO.md)부터 읽으세요.**
브라우저 IDE의 파일 편집기·터미널을 사용하므로 개인 PC에 VS Code가 꼭 있어야 하는 것은 아닙니다.
터미널에 `user:~$` 같은 표시가 보이면 `codex`를 입력하고, 실행 후 AI 입력창에서 한국어로 요청합니다.
`/codex`는 프로그램 실행 명령이 아닙니다. `/model`, `/mcp`는 Codex가 실행된 뒤 쓰는 명령입니다.

Python 설치 여부는 실제 원격 환경에서 확인합니다. `python`이 없고 `python3`만 있을 수도 있습니다.
이 키트의 Python 도구는 3.10 이상이 필요하지만, Markdown Skill 지침은 Python 없이 읽을 수 있습니다.
없는 실행기를 설치됐다고 가정하거나 모든 후보 라이브러리를 한꺼번에 설치하지 않습니다.

공개 저장소: https://github.com/TRX1200/HynixHack_won

제공된 AI에게 다음처럼 요청할 수 있습니다.

> 이 공개 저장소를 과제와 구분되는 새 폴더에 Clone하고 저장소의 START_HERE_KO.md를 읽어 주세요.
> 체크섬을 확인한 소스 압축파일을 새 `_toolkit` 폴더로 풀고 docs/FIRST_15_MINUTES_KO.md를 읽어 주세요.
> 기존 과제 파일과 설정을 덮어쓰지 말고
> 실제 실행기부터 확인해 주세요. 우선 wb-start와 wb-verify만 적용하고 인식 여부를
> 확인해 주세요. 필요한 계산이나 MCP가 있으면 단위·가정·통신 범위와 실제 호출까지 확인해 주세요.

공개 배포 루트에는 시작 안내와 `toolkit-source.zip`이 있고, 실제 소스는 압축 안의
`_toolkit/`에 있습니다. 이미 이 README와 tools/docs 폴더가 함께 보이면 압축 해제된 상태입니다.

## 먼저 읽기
0. `docs/FIRST_15_MINUTES_KO.md`: 터미널과 AI 입력 구분, Python 없는 경우, 첫 실행
1. `docs/QUICKSTART_KO.md`: 실제 시작과 설치·실행
2. `docs/DECISION_PLAYBOOK_KO.md`: 상황별 판단
3. `docs/HUMAN_KNOWLEDGE_KO.md`: 사용자가 이해해야 할 것
4. `docs/REPORT_WRITING_KO.md`: 보고서 요령과 제출물
5. `docs/COMPLIANCE.md`: 권한·보안·시험 사용 경계
6. `TEST_RESULTS.md`: 실제 실행한 검증 범위와 미검증 범위
7. `docs/ELECTRONICS_CALCULATORS_KO.md`: 단위와 가정을 명시한 회로·공정 기초 계산
8. `docs/EXTRA_MCP_KO.md`: 웹 검증/데이터 분석 MCP 후보와 연결 조건
9. `docs/WEB_UI_KO.md`: 웹 UI·아이콘·차트 OSS 후보와 선택 기준

## 기본 실행
Python 3.10 이상. 기본 기능은 추가 패키지 설치 불필요합니다.

```bash
python tools/run.py doctor
python -m unittest discover -s tests -v
python tools/smoke_mcp.py
python tools/run.py csv-profile examples/sample.csv --key item_id
python tools/run.py order examples/order_ambiguous.json
```

- 원본 입력은 수정하지 않습니다. 출력이 존재하면 덮어쓰지 않고 중단합니다.
- 기본 Python 도구는 네트워크/API/브라우저 자동조작/화면 캡처를 사용하지 않습니다.
- PDF 추출에는 PyMuPDF, 이미지 처리에는 Pillow가 선택적으로 필요합니다. 자동 설치하지 않습니다.
- `mcp/local_evidence_server.py`는 한 개의 명시된 로컬 JSONL 색인만 읽습니다. 읽기 전용 도구 3개이며 추가 AI를 호출하지 않습니다.
- 인터넷 없이 동작한다는 설계와 완전한 보안 격리는 다릅니다. 운영 환경의 권한 제한을 유지하십시오.

## Skill 선택
| Skill | 용도 |
|---|---|
| wb-start | 과제·환경·제출 조건 확인과 작업 유형 선택 |
| wb-intake | 업무 담당자에게 필요한 질문과 요구사항 확정 |
| wb-vision | 이미지 목록·확대·좌표·차이 후보 검증 |
| wb-docs | 문서 근거 검색과 규칙·예외 구조화 |
| wb-data | CSV·키·결합·집계 검증 |
| wb-build | 작은 기능부터 구현하고 실제 실행 |
| wb-debug | 실패 재현·원인 분리·최소 수정 |
| wb-optimize | 제약 정의·작은 배정/순서 문제·독립 검증 |
| wb-verify | 요구사항별 실제 검사와 오류 재검증 |
| wb-report | 근거 연결 보고서·표·산출물 작성 |
| wb-explain | AI 허용 단계에서 본인 이해 점검 |
| wb-finish | 필수 파일·저장·실행·제출 전 확인 |

한 번에 모두 적용하지 마십시오. `wb-start` + 해당 유형 + `wb-verify`가 기본입니다.
저장소를 작업 폴더 아래에 clone했다고 Skill이 자동 발견되는 것은 아닙니다.
호스트가 허용하면 `tools/install_skills.py`로 **선택한 Skill만** 프로젝트의 `.agents/skills`에 복사하십시오.
선택한 지침과 MIT 라이선스를 함께 복사하며, 중복 선택은 복사 전에 거절합니다.
이미 존재하는 Skill, AGENTS.md, 전역 설정, Codex 버전을 변경하지 않습니다.
자동 탐지가 안 되면 해당 `SKILL.md`를 명시적으로 읽으십시오. 기능 제한을 우회하거나 Codex를 업데이트하지 마십시오.

## 경계
공개 도구 반입이 허용된 환경에서만 사용하십시오. 특정 평가의 허가를 대신하지 않습니다.
실제 문제·안내 원문·개인정보·코드·답안·작업 로그·토큰을 이 공개 저장소에 추가하지 마십시오.
준비 전용 게시 도구는 이 저장소에 포함하지 않습니다. 실제 응시 중 업로드·Git push를 하지 마십시오.

## v1.1 확장: 기존 검증 도구 + 분야별 선택/검증 지침
- `docs/CAPABILITY_ROUTING_KO.md`: 이미지·수식·물리·통계·시각화 선택 기준
- `docs/LIBRARY_CATALOG_KO.md` / `catalog/libraries.json`: 16개 공식 라이브러리 후보, 용도와 한계
- `docs/LANGUAGE_PIPELINE_KO.md`: Python/JS/TS/SQL 선택과 단위·ID·결측 데이터 계약
- 추가 Skill: `wb-graphics`, `wb-visualize`, `wb-stack`, `wb-pipeline`, `wb-physics`, `wb-stats`
- `examples/bridge`: 추가 패키지 없는 Python -> JSON -> Node 연결 예제
- `tools/library_inventory.py`: 설치된 후보 패키지 메타데이터 확인(자동 설치 안 함)
- `tools/numeric_smoke.py`: 선택 의존성이 있으면 기호/수치 RC 예제와 합성 Welch/paired 검정 확인

기존 v1.0.0을 포함한 전체 패키지다. 두 버전 폴더를 덮어 합치지 말고 별도 폴더에서 검증한다.
이미 생성된 원격 저장소에 자동 반영되지 않는다. 공개 게시 상태를 주장하지 않는다.
추가 Skill은 재사용 지침이며 완성형 통계/물리/영상 엔진은 아니다. 전체 기능·Cofa 호환성은 보장하지 않는다.

## v1.1.1 검토·개선
- 초보자 시작 안내, 실행기 탐지와 Python 없는 경우의 대안을 보강했습니다.
- `tools/mcp_config.py --index <색인>`이 현재 Python과 실제 절대경로로 MCP JSON을 생성합니다.
  설정을 자동 등록하지 않으며, 기존 MCP 서버와 병합한 뒤 호스트 안내대로 저장·재실행·실제 호출을 확인해야 합니다.
- 큰 Decimal 합계/배정 비용, 엄격 JSON/CSV 입력, 문서 추출·검색, 이미지 차이 수치, 보고서 검증을 고쳤습니다.
- MCP 요청 검사와 UTF-8 출력을 보강하고 실제 로컬 프로세스 테스트를 추가했습니다.
- 원본의 Linux 실행 기록과 이번 Windows 검증을 구분해 보존합니다. 상세 변경은 `CHANGELOG.md`, 실제 검증은 `TEST_RESULTS.md`를 확인하세요.

## v1.2.0 회로·공정 기초 계산과 선택 MCP
- `calculate`는 Python 표준 라이브러리로 실행하는 교육용 기초 계산입니다. 외부 AI/API/패키지가 필요 없습니다.
- 입력 단위와 모델 가정, 알려진 검산값은 `docs/ELECTRONICS_CALCULATORS_KO.md`에 있습니다.
- 원본 입력을 바꾸거나 회로/공정 설계의 타당성을 자동 판정하지 않습니다. 제공된 조건에 맞는 식인지 먼저 확인합니다.
- Playwright MCP 설정은 **선택 예시**이며 런타임/브라우저/호스트 실제 연결을 별도 확인해야 합니다.
- DuckDB MCP는 데이터 문제에서 검토할 후보로만 설명합니다. 외부 접근 제한을 검증하지 않은 활성 설정은 포함하지 않습니다.
- 기본 Skills 두 개와 제공 도구부터 시작하고, 문제에 필요한 기능만 추가합니다.
